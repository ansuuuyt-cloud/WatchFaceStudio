# Watch Face Studio
Black-and-red Android starter app for Noise Twist Go custom-face experiments.

Includes gallery photo selection, a watch mockup preview, time/date color choices, clock-style and position controls, and a GitHub Actions APK build workflow.

**Important:** Applying a custom face to the Noise Twist Go is not implemented yet. Its compatible transfer protocol must be confirmed first. The Apply button clearly explains this and does not falsely claim success.

## Build from your phone
1. Create a GitHub repository named `WatchFaceStudio`.
2. Upload the CONTENTS of this ZIP to the repository root.
3. Open Actions and run **Build Android APK**.
4. Download the `WatchFaceStudio-debug-apk` artifact from the successful workflow run.
