package com.watchfacestudio.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val red = Color.rgb(255, 20, 55)
    private val black = Color.rgb(8, 8, 10)
    private var chosenColor = red
    private var style = "Digital"
    private var position = "Top"
    private lateinit var photo: ImageView
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var styleButton: Button
    private lateinit var positionButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(black)
        }
        scroll.addView(root)
        root.addView(label("WATCH FACE STUDIO", 25, Color.WHITE, true, Gravity.CENTER))
        root.addView(label("YOUR STYLE • YOUR WATCH • YOUR FACE", 11, red, true, Gravity.CENTER))
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(14), dp(12), dp(14))
            background = shape(Color.rgb(24,24,29), 20)
        }
        val frame = FrameLayout(this).apply { background = shape(Color.BLACK, 28); setPadding(dp(6),dp(6),dp(6),dp(6)) }
        photo = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.rgb(50,40,40))
            setImageResource(android.R.drawable.ic_menu_gallery)
        }
        frame.addView(photo, FrameLayout.LayoutParams(dp(190), dp(250)))
        val overlay = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        clock = label("10:08", 32, chosenColor, true, Gravity.CENTER)
        date = label("Sat 26", 13, Color.WHITE, false, Gravity.CENTER)
        overlay.addView(clock); overlay.addView(date)
        frame.addView(overlay, FrameLayout.LayoutParams(dp(190), dp(250)))
        card.addView(frame)
        card.addView(label("LIVE PREVIEW", 12, red, true, Gravity.CENTER))
        root.addView(card)
        root.addView(label("CUSTOMIZE", 15, red, true, Gravity.START))
        root.addView(button("Select Photo from Gallery") { pickPhoto() })
        root.addView(button("Time & Date Color") { colors() })
        styleButton = button("Clock Style: $style") { styles() }; root.addView(styleButton)
        positionButton = button("Clock Position: $position") { positions() }; root.addView(positionButton)
        root.addView(label("Clock text size", 13, Color.WHITE, false, Gravity.START))
        root.addView(SeekBar(this).apply {
            max = 36; progress = 16
            progressTintList = android.content.res.ColorStateList.valueOf(red)
            thumbTintList = android.content.res.ColorStateList.valueOf(red)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { clock.textSize = (18 + p / 2).toFloat() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        root.addView(button("APPLY TO NOISE TWIST GO") {
            AlertDialog.Builder(this).setTitle("Watch transfer not confirmed")
                .setMessage("Photo preview and customization are available. Sending a custom face to Noise Twist Go still needs a confirmed compatible transfer protocol. This starter build has not applied a face to the watch.")
                .setPositiveButton("OK", null).show()
        })
        root.addView(label("BLACK + RED EDITION • VERSION 1.0", 11, Color.LTGRAY, false, Gravity.CENTER))
        setContentView(scroll)
    }

    private fun pickPhoto() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"
        }, 101)
    }

    @Deprecated("Compatible with older Android devices")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri)?.use { photo.setImageBitmap(BitmapFactory.decodeStream(it)) }
                Toast.makeText(this, "Photo loaded into preview", Toast.LENGTH_SHORT).show()
            } catch (_: Exception) { Toast.makeText(this, "Could not open photo", Toast.LENGTH_SHORT).show() }
        }
    }

    private fun colors() {
        val names = arrayOf("Red", "White", "Cyan", "Yellow", "Green", "Blue", "Purple")
        val values = intArrayOf(red, Color.WHITE, Color.CYAN, Color.YELLOW, Color.GREEN, Color.BLUE, Color.MAGENTA)
        AlertDialog.Builder(this).setTitle("Time & Date Color").setItems(names) { _, i ->
            chosenColor = values[i]; clock.setTextColor(chosenColor); date.setTextColor(chosenColor)
        }.show()
    }
    private fun styles() {
        val values = arrayOf("Digital", "Minimal Digital", "Analog preview")
        AlertDialog.Builder(this).setTitle("Clock Style").setItems(values) { _, i ->
            style = values[i]
            clock.text = when(style) { "Minimal Digital" -> "10 08"; "Analog preview" -> "◷"; else -> "10:08" }
            styleButton.text = "Clock Style: $style"
        }.show()
    }
    private fun positions() {
        val values = arrayOf("Top", "Center", "Bottom")
        AlertDialog.Builder(this).setTitle("Clock Position").setItems(values) { _, i ->
            position = values[i]; positionButton.text = "Clock Position: $position"
            Toast.makeText(this, "Position selected: $position", Toast.LENGTH_SHORT).show()
        }.show()
    }
    private fun label(text: String, size: Int, color: Int, bold: Boolean, gravityValue: Int) = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color); gravity = gravityValue
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(4), dp(9), dp(4), dp(9))
    }
    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false; textSize = 14f; setTextColor(Color.WHITE)
        background = shape(red, 14); setPadding(dp(8), dp(7), dp(8), dp(7))
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(8) }
    }
    private fun shape(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
